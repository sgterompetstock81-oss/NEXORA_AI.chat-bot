# Dino AI

A responsive AI chat website with a plain HTML/CSS/JavaScript frontend and a Node.js backend that calls Google Gemini.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/dino-ai run dev` — run the Dino AI web app
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- Required secret for Gemini replies: `GEMINI_API_KEY`
- Chat history is stored in browser local storage; no database is required.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Web: Vite-served plain HTML, CSS, and JavaScript
- API: Express 5 on the shared Node.js API server
- Gemini: Google Gemini REST API called only from the server
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/dino-ai/` — Dino AI web UI
- `artifacts/api-server/src/routes/chat.ts` — secure Gemini chat endpoint
- `lib/api-spec/openapi.yaml` — API contract
- `README.md` — setup and run instructions

## Architecture decisions

- Keep the Gemini key in the API server environment; never expose it to browser code.
- Keep conversations in browser storage to avoid requiring a database for the initial setup.

## Product

- Start and switch between conversations, send messages by button or Enter, and keep conversation history in the current browser.
- Gemini is optional during initial setup; without a key the API returns a helpful configuration message.

## User preferences

- The initial setup must not require paid services.
- Use plain HTML, CSS, and JavaScript for the frontend.

## Gotchas

- Both the `artifacts/api-server: API Server` and `artifacts/dino-ai: web` workflows must be running for chat replies.
- Add `GEMINI_API_KEY` using Replit Secrets; do not put it in frontend files or commit it.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
