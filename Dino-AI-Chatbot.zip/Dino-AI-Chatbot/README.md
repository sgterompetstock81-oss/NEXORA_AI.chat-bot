# Dino AI

Dino AI is a responsive chat website with a plain HTML, CSS, and JavaScript frontend and a Node.js backend that calls Google Gemini. Chat history is saved in your browser; the initial setup does not need a database, paid hosting add-on, or third-party storage service.

## Run in Replit

1. To enable AI replies, add a Replit Secret named `GEMINI_API_KEY` with a Google AI Studio API key. Do not put the key in frontend files or commit it to this repository. Gemini's available free quota and limits are set by Google and may change.
2. Start the **API Server** and **Dino AI: web** workflows.
3. Open the Dino AI web preview. The chat interface also loads without a key; sending a message will show instructions if `GEMINI_API_KEY` is missing.

The API server and website are separate services. Both workflows need to be running for chat replies to work.

## Run from a terminal

Install workspace packages with `pnpm install`, then provide `GEMINI_API_KEY` through your shell's environment or your deployment's secret manager. Never place a real key in a checked-in `.env` file.

In separate terminals, start the API server and website:

```sh
PORT=5000 pnpm --filter @workspace/api-server run dev
```

```sh
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/dino-ai run dev
```

The Replit workflows supply the app's service ports and route `/api` requests to the Node API. When running outside Replit, use a reverse proxy that routes `/api` to the API server.

## API and security

- `POST /api/chat` accepts recent user/assistant messages and returns a Gemini reply.
- The Node API reads `GEMINI_API_KEY` from its environment and sends it to Gemini in a request header.
- The browser never receives the key.
- If no key is configured, the API returns a helpful setup message instead of crashing.
- Gemini quota limits and availability are controlled by Google. The app does not use a paid database or storage service.

## Chat history

Conversations are stored in the current browser's local storage. Clearing that browser storage removes the saved conversations; they are not synced across devices.
