const STORAGE_KEY = "dino-ai-conversations-v1";
const dinosaurMark = `<svg viewBox="0 0 32 32" fill="none" aria-hidden="true"><path d="M8 22.5c1.7-2.1 2.7-4.4 2.7-7.1 0-4.3 2.2-7.7 5.6-7.7 3.1 0 5.1 2.4 5.1 5.9 0 1.1-.2 2.1-.5 3.1l3.3 2.3-1.3 2.2-4.7-1.3c-1 .7-2.2 1.1-3.5 1.1-1.1 0-2.1-.3-3-.8-.4 1.1-1 2.2-1.8 3.2l-1.9-.9Zm6.4-10.1a1.2 1.2 0 1 0 0 2.4 1.2 1.2 0 0 0 0-2.4Z" fill="#B9B1FF"/><path d="M17.8 6.2c.4-2.1 2.4-3.5 4.7-3.2-.2 2.3-1.8 4-4 4.1" stroke="#72D7E7" stroke-width="1.6" stroke-linecap="round"/></svg>`;

const view = document.querySelector("#conversationView");
const historyNode = document.querySelector("#history");
const input = document.querySelector("#messageInput");
const form = document.querySelector("#chatForm");
const sendButton = document.querySelector("#sendButton");
const sidebar = document.querySelector("#sidebar");
const backdrop = document.querySelector("#backdrop");
const chatLabel = document.querySelector("#chatLabel");
let conversations = readConversations();
let activeId = null;
let isLoading = false;
let failed = false;

function readConversations() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(saved) ? saved.filter((item) =>
      item && typeof item.id === "string" && Array.isArray(item.messages)
    ) : [];
  } catch {
    return [];
  }
}

function saveConversations() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations));
  } catch {
    showStorageNotice();
  }
}

function showStorageNotice() {
  const notice = document.createElement("div");
  notice.className = "bubble";
  notice.textContent = "This chat can’t be saved in this browser right now. Your current conversation will stay open until you leave.";
  notice.style.margin = "12px auto";
  view.append(notice);
}

function currentConversation() {
  return conversations.find((item) => item.id === activeId) || null;
}

function makeId() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function createConversation() {
  const conversation = {
    id: makeId(),
    title: "A fresh thought",
    messages: [],
    updatedAt: new Date().toISOString()
  };
  conversations.unshift(conversation);
  activeId = conversation.id;
  failed = false;
  saveConversations();
  closeSidebar();
  render();
  input.focus();
}

function shortDate(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  const now = new Date();
  const today = date.toDateString() === now.toDateString();
  return today ? "Today" : new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(date);
}

function renderHistory() {
  historyNode.replaceChildren();
  const ordered = [...conversations].sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
  if (!ordered.length) {
    const empty = document.createElement("div");
    empty.style.cssText = "padding:10px 12px;color:#75748a;font-size:11px;line-height:1.6";
    empty.textContent = "Your conversations will find a home here.";
    historyNode.append(empty);
    return;
  }
  ordered.forEach((conversation) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `history-item${conversation.id === activeId ? " active" : ""}`;
    button.dataset.testid = `button-conversation-${conversation.id}`;
    button.setAttribute("aria-current", conversation.id === activeId ? "page" : "false");
    const title = document.createElement("span");
    title.className = "history-title";
    title.textContent = conversation.title || "A fresh thought";
    const date = document.createElement("span");
    date.className = "history-date";
    date.textContent = shortDate(conversation.updatedAt);
    button.append(title, date);
    button.addEventListener("click", () => {
      activeId = conversation.id;
      failed = false;
      closeSidebar();
      render();
    });
    historyNode.append(button);
  });
}

function createWelcome() {
  const wrapper = document.createElement("div");
  wrapper.className = "welcome";
  wrapper.innerHTML = `<div class="welcome-symbol">${dinosaurMark}</div><h1>Big thoughts,<br><em>small beginnings.</em></h1><p>A friendly place to follow a question, untangle an idea, or just see where your curiosity goes.</p>`;
  const suggestions = document.createElement("div");
  suggestions.className = "suggestions";
  [
    "Why do we dream?",
    "Help me think through an idea",
    "Explain something surprising"
  ].forEach((text) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "suggestion";
    button.textContent = text;
    button.dataset.testid = `button-suggestion-${text.toLowerCase().replaceAll(" ", "-")}`;
    button.addEventListener("click", () => {
      input.value = text;
      resizeInput();
      input.focus();
      form.requestSubmit();
    });
    suggestions.append(button);
  });
  wrapper.append(suggestions);
  return wrapper;
}

function makeMessage(message) {
  const row = document.createElement("article");
  row.className = `message ${message.role}`;
  row.dataset.testid = `message-${message.role}-${message.id}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  if (message.role === "assistant") avatar.innerHTML = dinosaurMark;
  else {
    avatar.setAttribute("aria-label", "You");
    avatar.textContent = "Y";
    avatar.style.cssText = "font-size:11px;font-weight:700;color:#d3d0ff";
  }
  const body = document.createElement("div");
  body.className = "message-body";
  const name = document.createElement("div");
  name.className = "message-name";
  name.textContent = message.role === "user" ? "You" : "Dino";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = message.content;
  body.append(name, bubble);
  if (message.role === "user") row.append(body, avatar);
  else row.append(avatar, body);
  return row;
}

function makeFailure() {
  const row = document.createElement("div");
  row.className = "message message-error";
  row.setAttribute("role", "alert");
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.innerHTML = dinosaurMark;
  const body = document.createElement("div");
  body.className = "message-body";
  const name = document.createElement("div");
  name.className = "message-name";
  name.textContent = "Couldn’t reach Dino";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.dataset.testid = "status-chat-error";
  bubble.textContent = failed;
  const retry = document.createElement("button");
  retry.type = "button";
  retry.className = "suggestion";
  retry.textContent = "Try again";
  retry.dataset.testid = "button-retry";
  retry.style.marginTop = "9px";
  retry.addEventListener("click", retryLastMessage);
  body.append(name, bubble, retry);
  row.append(avatar, body);
  return row;
}

function makeTyping() {
  const row = document.createElement("div");
  row.className = "message";
  row.setAttribute("role", "status");
  row.dataset.testid = "status-thinking";
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.innerHTML = dinosaurMark;
  const body = document.createElement("div");
  body.className = "message-body";
  const name = document.createElement("div");
  name.className = "message-name";
  name.textContent = "Dino is thinking";
  const dots = document.createElement("div");
  dots.className = "bubble typing";
  dots.innerHTML = "<span></span><span></span><span></span>";
  body.append(name, dots);
  row.append(avatar, body);
  return row;
}

function render() {
  const conversation = currentConversation();
  view.replaceChildren();
  chatLabel.textContent = conversation?.title || "A fresh thought";
  if (!conversation || conversation.messages.length === 0) {
    view.append(createWelcome());
  } else {
    const messages = document.createElement("div");
    messages.className = "messages";
    conversation.messages.forEach((message) => messages.append(makeMessage(message)));
    if (isLoading) messages.append(makeTyping());
    if (failed) messages.append(makeFailure());
    view.append(messages);
  }
  renderHistory();
  updateSendButton();
  requestAnimationFrame(() => {
    const scroller = document.querySelector("#chatScroll");
    scroller.scrollTop = scroller.scrollHeight;
  });
}

function updateSendButton() {
  sendButton.disabled = isLoading || !input.value.trim();
  sendButton.setAttribute("aria-busy", String(isLoading));
}

function resizeInput() {
  input.style.height = "auto";
  input.style.height = `${Math.min(input.scrollHeight, 160)}px`;
  updateSendButton();
}

async function sendMessage({ retry = false } = {}) {
  if (isLoading) return;
  let conversation = currentConversation();
  if (!conversation && !retry) {
    conversation = {
      id: makeId(),
      title: "A fresh thought",
      messages: [],
      updatedAt: new Date().toISOString()
    };
    conversations.unshift(conversation);
    activeId = conversation.id;
  }
  if (!conversation) return;
  let latestUser = conversation.messages.filter((message) => message.role === "user").at(-1);
  if (!retry) {
    const content = input.value.trim();
    if (!content) return;
    const userMessage = { id: makeId(), role: "user", content, createdAt: new Date().toISOString() };
    conversation.messages.push(userMessage);
    latestUser = userMessage;
    if (conversation.messages.filter((message) => message.role === "user").length === 1) {
      conversation.title = content.length > 38 ? `${content.slice(0, 38).trimEnd()}…` : content;
    }
    conversation.updatedAt = new Date().toISOString();
    input.value = "";
    resizeInput();
    failed = false;
    saveConversations();
  }
  if (!latestUser) return;
  isLoading = true;
  failed = false;
  render();
  input.blur();

  try {
    const messages = conversation.messages
      .filter((message) => message.role === "user" || message.role === "assistant")
      .slice(-30)
      .map(({ role, content }) => ({ role, content }));
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages })
    });
    let result = {};
    try {
      result = await response.json();
    } catch {
      result = {};
    }
    if (!response.ok) throw new Error(result.error || `Dino couldn’t reply (HTTP ${response.status}). Please try again.`);
    if (typeof result.reply !== "string" || !result.reply.trim()) throw new Error("Dino sent an empty reply. Please try again.");
    conversation.messages.push({
      id: makeId(),
      role: "assistant",
      content: result.reply,
      createdAt: new Date().toISOString()
    });
    conversation.updatedAt = new Date().toISOString();
    saveConversations();
  } catch (error) {
    failed = error instanceof Error ? error.message : "Something went wrong. Please try again.";
  } finally {
    isLoading = false;
    render();
    if (!failed && window.matchMedia("(max-width: 760px)").matches) input.blur();
  }
}

function retryLastMessage() {
  sendMessage({ retry: true });
}

function openSidebar() {
  sidebar.classList.add("open");
  backdrop.classList.add("show");
}
function closeSidebar() {
  sidebar.classList.remove("open");
  backdrop.classList.remove("show");
}

document.querySelector("#newChat").addEventListener("click", createConversation);
document.querySelector("#menuToggle").addEventListener("click", openSidebar);
backdrop.addEventListener("click", closeSidebar);
form.addEventListener("submit", (event) => {
  event.preventDefault();
  sendMessage();
});
input.addEventListener("input", resizeInput);
input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    form.requestSubmit();
  }
});
document.addEventListener("keydown", (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    createConversation();
  }
  if (event.key === "Escape") closeSidebar();
});

render();
