import { Router, type IRouter } from "express";
import { SendChatMessageBody, SendChatMessageResponse } from "@workspace/api-zod";
import {
  fetchGeminiWithRetry,
  GEMINI_BUSY_MESSAGE,
  isGeminiTimeoutError,
} from "../lib/gemini-retry";

const router: IRouter = Router();
const GEMINI_MODEL = "gemini-3.8-flash";
const GEMINI_ENDPOINT = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

type GeminiPayload = {
  candidates?: Array<{
    content?: {
      parts?: Array<{ text?: string }>;
    };
  }>;
};

type GeminiErrorPayload = {
  error?: {
    code?: number;
    status?: string;
    message?: string;
  };
};

function getReply(payload: unknown): string | undefined {
  if (typeof payload !== "object" || payload === null) {
    return undefined;
  }

  const candidates = (payload as GeminiPayload).candidates;
  const parts = candidates?.[0]?.content?.parts;
  const text = parts
    ?.map((part) => part.text)
    .filter((part): part is string => typeof part === "string")
    .join("")
    .trim();

  return text || undefined;
}

function getProviderError(payload: unknown): GeminiErrorPayload["error"] {
  if (typeof payload !== "object" || payload === null) {
    return undefined;
  }

  const error = (payload as GeminiErrorPayload).error;
  if (typeof error !== "object" || error === null) {
    return undefined;
  }

  return {
    code: typeof error.code === "number" ? error.code : undefined,
    status: typeof error.status === "string" ? error.status : undefined,
    message: typeof error.message === "string" ? error.message : undefined,
  };
}

router.post("/chat", async (req, res): Promise<void> => {
  const parsed = SendChatMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Please send a valid chat message." });
    return;
  }

  const messages = parsed.data.messages;
  if (messages[messages.length - 1]?.role !== "user") {
    res.status(400).json({ error: "The latest message must be from you." });
    return;
  }

  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) {
    res.status(503).json({
      error:
        "Dino AI needs a Gemini API key before it can reply. Add GEMINI_API_KEY in Replit Secrets, then restart the API Server.",
    });
    return;
  }

  const contents = messages.map((message) => ({
    role: message.role === "assistant" ? "model" : "user",
    parts: [{ text: message.content }],
  }));

  while (contents[0]?.role === "model") {
    contents.shift();
  }

  try {
    const response = await fetchGeminiWithRetry(GEMINI_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey,
      },
      body: JSON.stringify({
        contents,
        generationConfig: { maxOutputTokens: 2048 },
      }),
    });

    if (!response.ok) {
      const providerError = getProviderError(
        await response.json().catch(() => undefined),
      );
      const providerMessage = providerError?.message
        ?.split(apiKey)
        .join("[redacted]")
        .slice(0, 500);

      req.log.warn(
        {
          model: GEMINI_MODEL,
          upstreamStatus: response.status,
          providerCode: providerError?.code,
          providerStatus: providerError?.status,
          providerMessage,
        },
        "Gemini request was rejected",
      );

      const providerStatus = providerError?.status;
      const quotaFailure =
        providerStatus === "RESOURCE_EXHAUSTED" ||
        /\bquota\b|\brate[- ]?limit/i.test(providerMessage ?? "");
      if (response.status === 429 || quotaFailure) {
        res.status(429).json({
          error:
            "Gemini is busy or its free quota has been reached. Wait a moment and try again.",
        });
        return;
      }

      if (
        response.status === 401 ||
        response.status === 403 ||
        providerStatus === "UNAUTHENTICATED" ||
        providerStatus === "PERMISSION_DENIED"
      ) {
        res.status(502).json({
          error:
            "Gemini rejected the API key or denied access. Check that GEMINI_API_KEY is a valid Google AI Studio key with Gemini API access.",
        });
        return;
      }

      if (response.status === 404 || providerStatus === "NOT_FOUND") {
        res.status(502).json({
          error: providerMessage
            ? `Gemini could not find or use model ${GEMINI_MODEL}: ${providerMessage}`
            : `Gemini could not find or use model ${GEMINI_MODEL}. Check that the model is available to this API key.`,
        });
        return;
      }

      if (response.status === 400 || providerStatus === "INVALID_ARGUMENT") {
        res.status(502).json({
          error: providerMessage
            ? `Gemini rejected the request: ${providerMessage}`
            : "Gemini rejected the request. Check the message and try again.",
        });
        return;
      }

      if (response.status === 503) {
        res.status(503).json({ error: GEMINI_BUSY_MESSAGE });
        return;
      }

      res.status(502).json({
        error: providerMessage
          ? `Gemini could not complete that reply: ${providerMessage}`
          : `Gemini could not complete that reply (HTTP ${response.status}). Please try again.`,
      });
      return;
    }

    const reply = getReply(await response.json());
    if (!reply) {
      res.status(502).json({
        error: "Gemini returned an empty reply. Please try again.",
      });
      return;
    }

    res.json(SendChatMessageResponse.parse({ reply }));
  } catch (error) {
    const timedOut = isGeminiTimeoutError(error);

    req.log.warn(
      { reason: timedOut ? "timeout" : "network" },
      "Gemini service could not be reached",
    );
    res.status(503).json({
      error: timedOut
        ? GEMINI_BUSY_MESSAGE
        : "Dino AI could not reach Gemini. Check your connection and try again.",
    });
  }
});

export default router;
