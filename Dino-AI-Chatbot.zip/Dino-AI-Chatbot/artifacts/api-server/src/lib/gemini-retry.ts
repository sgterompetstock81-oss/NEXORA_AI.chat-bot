export const GEMINI_BUSY_MESSAGE =
  "Gemini sedang sibuk. Tunggu sebentar, lalu coba lagi ya!";

export const GEMINI_RETRY_POLICY = Object.freeze({
  maxRetries: 2,
  attemptTimeoutMs: 20_000,
  maxDurationMs: 62_000,
  baseDelayMs: 500,
});

type RetryDependencies = {
  fetchImpl?: typeof fetch;
  wait?: (milliseconds: number) => Promise<void>;
  now?: () => number;
};

type ProviderError = {
  status?: string;
  message?: string;
  details?: unknown;
};

function defaultWait(milliseconds: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

export function isGeminiTimeoutError(error: unknown): boolean {
  const visited = new Set<unknown>();
  let current: unknown = error;

  while (
    current !== null &&
    (typeof current === "object" || typeof current === "function") &&
    !visited.has(current)
  ) {
    visited.add(current);
    const candidate = current as {
      name?: unknown;
      code?: unknown;
      cause?: unknown;
    };

    if (
      candidate.name === "TimeoutError" ||
      candidate.name === "AbortError" ||
      candidate.code === "ETIMEDOUT" ||
      candidate.code === "UND_ERR_CONNECT_TIMEOUT" ||
      candidate.code === "UND_ERR_HEADERS_TIMEOUT" ||
      candidate.code === "UND_ERR_BODY_TIMEOUT"
    ) {
      return true;
    }

    current = candidate.cause;
  }

  return false;
}

function isNonRetryableProviderError(body: string): boolean {
  let providerError: ProviderError | undefined;
  try {
    const payload: unknown = JSON.parse(body);
    if (typeof payload === "object" && payload !== null) {
      const error = (payload as { error?: unknown }).error;
      if (typeof error === "object" && error !== null) {
        providerError = error as ProviderError;
      }
    }
  } catch {
    return false;
  }

  if (!providerError) {
    return false;
  }

  const diagnostic = [
    providerError.status,
    providerError.message,
    JSON.stringify(providerError.details ?? ""),
  ]
    .filter((value): value is string => typeof value === "string")
    .join(" ");

  return /\b(?:RESOURCE_EXHAUSTED|PERMISSION_DENIED|UNAUTHENTICATED|NOT_FOUND|INVALID_ARGUMENT)\b|\bquota\b|\brate[- ]?limit(?:ed|ing)?\b|\bmodels?\b.{0,100}\b(?:not found|not supported|unsupported|invalid)\b|\b(?:not found|not supported|unsupported|invalid)\b.{0,100}\bmodels?\b|\b(?:invalid|unsupported)\s+model\b|\b(?:api key|authentication|authorization)\b.{0,100}\b(?:invalid|not valid|unauthorized|denied|expired|missing)\b|\b(?:invalid|unauthorized|denied|expired|missing)\b.{0,100}\b(?:api key|authentication|authorization)\b/i.test(
    diagnostic,
  );
}

async function cancelResponseBody(response: Response): Promise<void> {
  try {
    await response.body?.cancel();
  } catch {
    // The response body may already be closed after a timeout.
  }
}

export async function fetchGeminiWithRetry(
  input: string | URL,
  init: RequestInit,
  dependencies: RetryDependencies = {},
): Promise<Response> {
  const fetchImpl = dependencies.fetchImpl ?? fetch;
  const wait = dependencies.wait ?? defaultWait;
  const now = dependencies.now ?? Date.now;
  const deadline = now() + GEMINI_RETRY_POLICY.maxDurationMs;
  let retries = 0;

  while (true) {
    const remainingMs = deadline - now();
    if (remainingMs <= 0) {
      throw new DOMException("Gemini request deadline exceeded", "TimeoutError");
    }

    const timeoutMs = Math.max(
      1,
      Math.floor(
        Math.min(remainingMs, GEMINI_RETRY_POLICY.attemptTimeoutMs),
      ),
    );
    let response: Response | undefined;

    try {
      response = await fetchImpl(input, {
        ...init,
        signal: AbortSignal.timeout(timeoutMs),
      });

      // Read a clone so timeouts while receiving the body are retryable too;
      // the original response remains available to the route handler.
      const responseBody = await response.clone().text();
      if (
        response.status !== 503 ||
        retries >= GEMINI_RETRY_POLICY.maxRetries ||
        isNonRetryableProviderError(responseBody)
      ) {
        return response;
      }

      const delayMs =
        GEMINI_RETRY_POLICY.baseDelayMs * 2 ** retries;
      if (now() + delayMs >= deadline) {
        return response;
      }

      await cancelResponseBody(response);
      await wait(delayMs);
      retries += 1;
    } catch (error) {
      if (
        !isGeminiTimeoutError(error) ||
        retries >= GEMINI_RETRY_POLICY.maxRetries
      ) {
        throw error;
      }

      const delayMs =
        GEMINI_RETRY_POLICY.baseDelayMs * 2 ** retries;
      if (now() + delayMs >= deadline) {
        throw error;
      }

      if (response) {
        await cancelResponseBody(response);
      }
      await wait(delayMs);
      retries += 1;
    }
  }
}
